OC.L10N.register(
    "accessibility",
    {
    "Dark theme" : "黑暗主題",
    "A dark theme to ease your eyes by reducing the overall luminosity and brightness. It is still under development, so please report any issues you may find." : "黑暗風格的主題，通過降低整體亮度來舒緩對您眼睛的刺激。黑暗主題仍在開發中，如發現任何問題，煩請報告。",
    "High contrast mode" : "高對比度模式",
    "A high contrast mode to ease your navigation. Visual quality will be reduced but clarity will be increased." : "高對比度模式會降低界面質量，但會提高清晰度，有助您瀏覽。",
    "Dyslexia font" : "閱讀障礙字體",
    "OpenDyslexic is a free typeface/font designed to mitigate some of the common reading errors caused by dyslexia." : "OpenDyslexic 是一種免費的字型，目的在降低因拼音文字閱讀障礙引起的一些常見閱讀錯誤。",
    "Accessibility" : "協助工具",
    "Accessibility options for nextcloud" : "Nextcloud 協助工具設定",
    "Provides multiple accessibilities options to ease your use of Nextcloud" : "提供多種協助工具使您更易於操作 Nextcloud",
    "Web Content Accessibility Guidelines" : "網路內容協助工具指南",
    "our issue tracker" : "問題追蹤",
    "our design team" : "我們的設計團隊",
    "Enable" : "啟用",
    "High contrast theme" : "高對比主題",
    "A high contrast theme to ease your navigation. Visual quality will be reduced but clarity will be increased." : "使用高對比度主題以便於頁面導覽。提高操作理解程度，但視覺質感會下降。",
    "Dark theme (beta)" : "黑暗主題（測試）"
},
"nplurals=1; plural=0;");
