OC.L10N.register(
    "accessibility",
    {
    "Dark theme" : "Tema escuro",
    "A dark theme to ease your eyes by reducing the overall luminosity and brightness. It is still under development, so please report any issues you may find." : "Um tema escuro para aliviar os olhos, reduzindo a luminosidade e brilho geral. Ainda está em desenvolvimento, por isso, informe qualquer problema encontrado.",
    "High contrast mode" : "Modo de alto contraste",
    "A high contrast mode to ease your navigation. Visual quality will be reduced but clarity will be increased." : "O modo de alto contraste facilita a navegação. A qualidade visual será reduzida, mas a clareza será aumentada.",
    "Dyslexia font" : "Fonte de dislexia",
    "OpenDyslexic is a free typeface/font designed to mitigate some of the common reading errors caused by dyslexia." : "OpenDyslexic é um tipo de letra/fonte grátis concebida para atenuar alguns dos erros comuns de leitura causados pela dislexia.",
    "Accessibility" : "Acessibilidade",
    "Accessibility options for nextcloud" : "Opções de acessibilidade para nextcloud",
    "Provides multiple accessibilities options to ease your use of Nextcloud" : "Fornece várias opções de acessibilidade para facilitar o uso do Nextcloud",
    "Web Content Accessibility Guidelines" : "Diretrizes de Acessibilidade ao Conteúdo da Web",
    "our issue tracker" : "nosso rastreador de problemas",
    "our design team" : "nossa equipe de design",
    "Universal access is very important to us. We follow web standards and check to make everything usable also without mouse, and assistive software such as screenreaders. We aim to be compliant with the {guidelines} 2.1 on AA level, with the high contrast theme even on AAA level." : "O acesso universal é muito importante para nós. Seguimos os padrões da web e nos certificamos de tornar tudo utilizável também sem mouse e software auxiliar, como leitores de tela. Nosso objetivo é estar em conformidade com as {guidelines} 2.1 no nível AA, com o tema de alto contraste, mesmo no nível AAA.",
    "If you find any issues, don’t hesitate to report them on {issuetracker}. And if you want to get involved, come join {designteam}!" : "Se você encontrar algum problema, não hesite em reportá-lo no {issuetracker}. E se você quiser se envolver, junte-se ao {designteam}!",
    "Enable" : "Ativar",
    "High contrast theme" : "Tema de alto contraste",
    "A high contrast theme to ease your navigation. Visual quality will be reduced but clarity will be increased." : "Um tema de alto contraste para facilitar a navegação. A qualidade visual será reduzida, mas a clareza aumentada.",
    "Dark theme (beta)" : "Tema escuro (beta)"
},
"nplurals=2; plural=(n > 1);");
