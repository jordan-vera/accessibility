OC.L10N.register(
    "accessibility",
    {
    "Dark theme" : "Thème sombre",
    "A dark theme to ease your eyes by reducing the overall luminosity and brightness. It is still under development, so please report any issues you may find." : "Un thème sombre pour apaiser vos yeux en réduisant la luminosité et la clarté générales. Il est toujours en cours de développement, merci de  signaler tout problème que vous rencontrez.",
    "High contrast mode" : "Thème à contraste élevé",
    "A high contrast mode to ease your navigation. Visual quality will be reduced but clarity will be increased." : "Un thème au contraste élevé pour faciliter votre navigation. La qualité visuelle sera réduite, mais la clarté sera améliorée.",
    "Dyslexia font" : "Police pour dyslexiques",
    "OpenDyslexic is a free typeface/font designed to mitigate some of the common reading errors caused by dyslexia." : "OpenDyslexic est une police de caractères libre conçue pour atténuer certains problèmes de lecture causés par la dyslexie.",
    "Accessibility" : "Accessibilité",
    "Accessibility options for nextcloud" : "Options d'accessibilité pour Nextcloud",
    "Provides multiple accessibilities options to ease your use of Nextcloud" : "Fournit de nombreuses options d'accessibilité pour faciliter votre utilisation de Nextcloud",
    "Web Content Accessibility Guidelines" : "Règles pour l'accessibilité des contenus Web",
    "our issue tracker" : "notre outil de suivi des problèmes",
    "our design team" : "notre équipe de conception",
    "Universal access is very important to us. We follow web standards and check to make everything usable also without mouse, and assistive software such as screenreaders. We aim to be compliant with the {guidelines} 2.1 on AA level, with the high contrast theme even on AAA level." : "L'accès universel est très important pour nous. Nous suivons les standards du web et vérifions de tout rendre utilisable également sans souris, et avec des logiciels d'assistance technique tels que les lecteurs d'écran. Nous visons à respecter les {guidelines} 2.1 de niveau AA, et même de niveau AAA avec le thème à fort contraste.",
    "If you find any issues, don’t hesitate to report them on {issuetracker}. And if you want to get involved, come join {designteam}!" : "Si vous rencontrez un problème, n'hésitez pas à nous le signaler sur {issuetracker}. Et si vous souhaitez vous impliquer, rejoignez {designteam} !",
    "Enable" : "Activer",
    "High contrast theme" : "Thème à contraste élevé",
    "A high contrast theme to ease your navigation. Visual quality will be reduced but clarity will be increased." : "Un thème au contraste élevé pour faciliter votre navigation. La qualité visuelle sera réduite, mais la clarté sera améliorée.",
    "Dark theme (beta)" : "Thème sombre (beta)"
},
"nplurals=2; plural=(n > 1);");
